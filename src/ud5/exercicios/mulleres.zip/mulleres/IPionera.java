package ud5.exercicios.mulleres;

public interface IPionera {
    String getDescubrimientoOuAporte();
}
