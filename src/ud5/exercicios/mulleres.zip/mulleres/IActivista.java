package ud5.exercicios.mulleres;

public interface IActivista {
    String getCausaDefendida();
}
