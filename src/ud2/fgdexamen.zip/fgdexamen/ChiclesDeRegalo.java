/*
 * Daniel Fernandez Garcia
 */

package ud2.fgdexamen;

public class ChiclesDeRegalo {
    
    public static int totalChicles(int chiclesCom, int envoltoriosOferta, int chiclesOferta) {
        int chiclesFinal, chiclesObt;

        if (envoltoriosOferta > 0 && chiclesCom >= 0 && chiclesOferta >= 0 && chiclesOferta <= envoltoriosOferta) {
            chiclesObt = (chiclesCom / envoltoriosOferta) * chiclesOferta;
        chiclesFinal = chiclesObt + chiclesCom; 
        chiclesFinal = chiclesFinal + ((chiclesObt/envoltoriosOferta)*chiclesOferta);
        } else  if (envoltoriosOferta == 0) {
            chiclesFinal = chiclesCom;
        } else {
            chiclesFinal = -1;
        }

        return chiclesFinal;
    }

    public static void main(String[] args) {
        int chiclesCom, envoltoriosOferta, chiclesOferta;
        int output;

        chiclesCom = 20 ;
        envoltoriosOferta = 5 ;
        chiclesOferta = 5 ;

        output = totalChicles(chiclesCom, envoltoriosOferta, chiclesOferta);
        System.out.println(output);
    }
}
